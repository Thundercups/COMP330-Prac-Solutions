
"use strict";

class RayHit {
    constructor (t, position, normal) {
        this.t = t;
        this.position = position;
        this.normal = normal;
    }
}
